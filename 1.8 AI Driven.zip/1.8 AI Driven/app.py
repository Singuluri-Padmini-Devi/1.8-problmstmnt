from flask import Flask, request, jsonify, render_template  # Flask for web framework, handling requests and rendering templates
from werkzeug.utils import secure_filename  # For securely handling file uploads
import pytesseract  # For extracting text from images using Tesseract OCR
from PIL import Image  # For handling and processing image files
import os  # For operating system related tasks like creating directories
import json  # For handling JSON data format
import pdfplumber  # For extracting text from PDF files
import re  # Regular expressions for searching keywords in text
from whoosh.index import create_in  # To create a Whoosh index for storing searchable text
from whoosh.fields import Schema, TEXT  # Define schema for Whoosh index, using text fields
from whoosh.qparser import QueryParser  # For parsing search queries in Whoosh
from whoosh.writing import AsyncWriter  # Asynchronous writer for adding documents to Whoosh index


# Initialize Flask app and set template/static folders
app = Flask(__name__, template_folder='templates', static_folder='static')

# Set upload folder and allowed file extensions
UPLOAD_FOLDER = 'uploads/'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'tiff', 'jfif', 'webp', 'bmp', 'pdf'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure upload folder exists, create if not present
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Define Whoosh schema and create index directory if it doesn't exist
schema = Schema(content=TEXT(stored=True))
index_dir = "index"
if not os.path.exists(index_dir):
    os.mkdir(index_dir)
ix = create_in(index_dir, schema)

# Helper function to check if file has an allowed extension
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Helper function to extract text from an image using OCR (Tesseract)
def extract_text_from_image(image_path):
    try:
        image = Image.open(image_path)
        text = pytesseract.image_to_string(image)
        return text
    except Exception as e:
        return str(e)  # Return error as a string if something goes wrong

# Helper function to extract text from a PDF using pdfplumber
def extract_text_from_pdf(pdf_path):
    text = ""
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()  # Extract text from each page
                if page_text:  # Only add non-empty text
                    text += page_text + "\n"
    except Exception as e:
        return f"Error extracting text: {e}"  # Return error message if any
    return text

# Function to index the extracted text in Whoosh
def index_text(text):
    writer = AsyncWriter(ix)  # Open an asynchronous writer for the index
    writer.add_document(content=text)  # Add document to index
    writer.commit()  # Commit changes

# Function to find lines in the text containing the specified keyword
def find_keyword_in_text(text, keyword):
    lines = text.split('\n')  # Split the text into lines
    keyword_lines = {line for line in lines if re.search(r'\b{}\b'.format(re.escape(keyword)), line, re.IGNORECASE)}
    return keyword_lines  # Return lines containing the keyword

# Route to render the home page
@app.route('/')
def index():
    return render_template('index.html')  # Render the main HTML page

# Route to handle file upload, extract text, index, and return in different formats
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400  # Return error if no file is uploaded
    file = request.files['file']
    format_type = request.form.get('format')  # Get the format type (json/csv)
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400  # Return error if no file is selected
    
    if file and allowed_file(file.filename):  # Check if file is allowed
        filename = secure_filename(file.filename)  # Secure the filename
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)  # Save the file to the uploads folder

        # Determine if the file is a PDF or image, and extract text accordingly
        if filename.lower().endswith('.pdf'):
            text = extract_text_from_pdf(file_path)
        else:
            text = extract_text_from_image(file_path)

        index_text(text)  # Index the extracted text

        # Handle output formats (json, csv, or plain text)
        if format_type == 'json':
            json_output = json.dumps({'text': text}, indent=4)  # Return text in JSON format
            return jsonify({'json': json_output})
        elif format_type == 'csv':
            # Create CSV output with each line as a new row
            csv_output = 'text\n' + '\n'.join(f'"{line}"' for line in text.splitlines() if line.strip())
            return jsonify({'csv': csv_output})
        else:  # Default to plain text format
            return jsonify({'text': text})
    
    return jsonify({'error': 'Invalid file type'}), 400  # Return error if file type is invalid

# Route to handle search requests
@app.route('/search', methods=['POST'])
def search_text():
    data = request.json  # Get the search query from the request
    query_str = data.get('query', '').strip()  # Trim spaces around the query

    if not query_str:
        return jsonify({'error': 'Query not provided'}), 400  # Return error if no query is provided

    results = set()  # Initialize a set to store unique search results
    with ix.searcher() as searcher:
        query = QueryParser("content", ix.schema).parse(query_str)  # Parse the query
        search_results = searcher.search(query, limit=None)  # Perform search with no limit

        for hit in search_results:
            keyword_lines = find_keyword_in_text(hit['content'], query_str)  # Get lines containing the keyword
            results.update(keyword_lines)  # Add the found lines to the results set

    # Convert results set to a sorted list
    results = sorted(results)

    return jsonify({'results': results})  # Return the search results as JSON

# Run the Flask app in debug mode
if __name__ == '__main__':
    app.run(debug=True)
