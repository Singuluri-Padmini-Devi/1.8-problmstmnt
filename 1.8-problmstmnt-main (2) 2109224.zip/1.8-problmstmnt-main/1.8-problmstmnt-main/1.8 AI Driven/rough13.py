from flask import Flask, request, jsonify, render_template
from werkzeug.utils import secure_filename
import pytesseract
from PIL import Image
import os
import json
import pdfplumber
import re
from whoosh.index import create_in
from whoosh.fields import Schema, TEXT
from whoosh.qparser import QueryParser
from whoosh.writing import AsyncWriter

# Initialize Flask app and set template/static folders
app = Flask(__name__, template_folder='templates', static_folder='static')

# Set upload folder and allowed file extensions
UPLOAD_FOLDER = 'uploads/'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'tiff', 'jfif', 'webp', 'bmp', 'pdf'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure upload folder exists, create if not present
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Define Whoosh schema and create index directory if it doesn't exist
schema = Schema(content=TEXT(stored=True))
index_dir = "index"
if not os.path.exists(index_dir):
    os.mkdir(index_dir)
ix = create_in(index_dir, schema)

# Helper function to check if file has an allowed extension
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Helper function to extract text from an image using OCR (Tesseract)
def extract_text_from_image(image_path):
    try:
        image = Image.open(image_path)
        text = pytesseract.image_to_string(image)
        return text
    except Exception as e:
        return str(e)

# Helper function to extract text from a PDF using pdfplumber
def extract_text_from_pdf(pdf_path):
    text = ""
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
    except Exception as e:
        return f"Error extracting text: {e}"
    return text

# Function to index the extracted text in Whoosh
def index_text(text):
    writer = AsyncWriter(ix)
    writer.add_document(content=text)
    writer.commit()

# Function to find lines in the text containing the specified keyword
def find_keyword_in_text(text, keyword):
    lines = text.split('\n')
    keyword_lines = {line for line in lines if re.search(r'\b{}\b'.format(re.escape(keyword)), line, re.IGNORECASE)}
    return keyword_lines

# Function to convert extracted text to a structured CSV format
def text_to_csv(text):
    lines = text.splitlines()
    csv_rows = []

    for line in lines:
        if line.strip():  # Skip empty lines
            # Split by whitespace or another delimiter if needed
            fields = line.strip().split()
            # Join fields with commas for CSV formatting
            csv_rows.append(','.join(fields))

    # Join all rows with newlines
    csv_output = '\n'.join(csv_rows)
    return csv_output

# Route to render the home page
@app.route('/')
def index():
    return render_template('index.html')

# Route to handle file upload, extract text, index, and return in different formats
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    format_type = request.form.get('format')

    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        # Determine if the file is a PDF or image, and extract text accordingly
        if filename.lower().endswith('.pdf'):
            text = extract_text_from_pdf(file_path)
        else:
            text = extract_text_from_image(file_path)

        index_text(text)

        # Handle output formats (json, csv, or plain text)
        if format_type == 'json':
            json_output = json.dumps({'text': text}, indent=4)
            return jsonify({'json': json_output})
        elif format_type == 'csv':
            csv_output = text_to_csv(text)  # Convert text to CSV
            return jsonify({'csv': csv_output})
        else:  # Default to plain text format
            return jsonify({'text': text})

    return jsonify({'error': 'Invalid file type'}), 400

# Route to handle search requests
@app.route('/search', methods=['POST'])
def search_text():
    data = request.json
    query_str = data.get('query', '').strip()

    if not query_str:
        return jsonify({'error': 'Query not provided'}), 400

    results = set()
    with ix.searcher() as searcher:
        query = QueryParser("content", ix.schema).parse(query_str)
        search_results = searcher.search(query, limit=None)

        for hit in search_results:
            keyword_lines = find_keyword_in_text(hit['content'], query_str)
            results.update(keyword_lines)

    results = sorted(results)

    return jsonify({'results': results})

# Run the Flask app in debug mode
if __name__ == '__main__':
    app.run(debug=True)
